from botbuilder.core import TurnContext, ActivityHandler
from botbuilder.ai.luis import LuisApplication, LuisPredictionOptions, LuisRecognizer
from botbuilder.schema import ChannelAccount
import json
from .config_reader import ConfigReader
from mysql.connector import Error
import mysql.connector
#from .card_helper import create_card_attachment
from django.template.defaulttags import register


class LuisConnect(ActivityHandler):

    def __init__(self):
        self.config_reader = ConfigReader()
        self.configuration = self.config_reader.read_config()
        self.luis_app_id = self.configuration['LUIS_APP_ID']
        self.luis_endpoint_key = self.configuration['LUIS_ENDPOINT_KEY']
        self.luis_endpoint = self.configuration['LUIS_ENDPOINT']
        self.luis_app = LuisApplication(self.luis_app_id, self.luis_endpoint_key, self.luis_endpoint)
        self.luis_options = LuisPredictionOptions(include_all_intents=True, include_instance_data=True)
        self.luis_recognizer = LuisRecognizer(application=self.luis_app, prediction_options=self.luis_options,include_api_results=True)
        self.empid = ""

    async def on_message_activity(self, turn_context: TurnContext):
        print("calling db connection")
        con = mysql.connector.connect(host="localhost", user="root", passwd="root", database="chatbot")
        if (con):
            print("Connection successfully")
        else:
            print("UnSuccessfull")

        if turn_context.activity.value:
            print("Called here")
            Id = turn_context.activity.value["Id"]
            Name = turn_context.activity.value["Name"]
            Phone = turn_context.activity.value["Phone"]
            Address = turn_context.activity.value["Address"]

            mycursor = con.cursor()
            CreateAccount = f"INSERT INTO empselfservice (EmpId,EmpName,EmpPhoneNumber,EmpAddress) VALUES ('{Id}','{Name}','{Phone}','{Address}')"
            mycursor.execute(CreateAccount)
            con.commit()
            print(mycursor.rowcount, "records(s) affected")
            print("Account has been created")
            await  turn_context.send_activity("Your Account has been created..!")
            CreatedAccountDetails = f"select * from empselfservice where EmpId='{Id}'"
            mycursor.execute(CreatedAccountDetails)
            fetchAccountDetails = mycursor.fetchall()
            await turn_context.send_activity("Your Account Details are : {}".format(fetchAccountDetails))

        if (turn_context.activity.text):
            luis_result = await self.luis_recognizer.recognize(turn_context)
            intent = LuisRecognizer.top_intent(luis_result)
            print(intent, " is intent")

            if intent != None:

                result = luis_result.properties["luisResult"]
                '''json_code_str = json.loads((str(result.entities[0])).replace("'", "\""))
                print(json_code_str)
                Entity = json_code_str.get('entity')
                print(Entity," is entity")'''
                # entity is present in utterance go into if :
                if result.entities:
                    print("result.entities = ", result.entities)  # it returns hashcode value
                    for i in result.entities:
                        print("dictioionary of entities = ", i)  # is dictionary of additional properties
                        Entity = i.entity  # entity is key from dict
                        # Score = i.role#score is key from dict
                        type = i.type  # key from dict
                        start_index = i.start_index  # key from dict
                        end_index = i.end_index  # key from dict

                        print("entity is =", Entity)
                        # print("Score is =", Score)
                        print("type  is =", type)
                        print("start_index  is =", start_index)
                        print("end_index  is =", end_index)

                #if intent :

            else:
                print("Cannot print None intent")

    async def on_members_added_activity(
            self, members_added: [ChannelAccount], turn_context: TurnContext
    ):
        for member_added in members_added:
            if member_added.id != turn_context.activity.recipient.id:
                await turn_context.send_activity("Welcome to Employee_Details ! ")
                await turn_context.send_activity("Please Enter your Employee Code ")