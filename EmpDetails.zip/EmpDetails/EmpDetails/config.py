class DefaultBotConfig(object):
    PORT = 8000
    APP_ID = ""
    APP_PASSWORD = ""
