from django.http import HttpResponse
import sys
import json
import asyncio
from django.apps import AppConﬁg
from django.apps import apps
from botbuilder.schema import Activity
from botbuilder.core import (
    BotFrameworkAdapter,
    BotFrameworkAdapterSettings,
    TurnContext,
    ConversationState,
    MemoryStorage,
    UserState,
    ShowTypingMiddleware
)


def messages(request):
    if "application/json" in request.headers["Content-type"]:
        body = json.loads(request.body.decode("utf-8"))
    else:
        return HttpResponse(Status=415)
    activity = Activity().deserialize(body)
    auth_header = (
        request.headers["Authorization"] if "Authorization" in request.headers else ""
    )

    bot_app = apps.get_app_config("SelfService")
    bot = bot_app.bot
    loop = bot_app.loop
    adapter = bot_app.adapter

    async def aux_func(turn_context):
        await bot.on_turn(turn_context)

    try:
        task = asyncio.ensure_future(
            adapter.process_activity(activity, auth_header, aux_func), loop=loop
        )
        loop.run_until_complete(task)

        return HttpResponse(status=201)
    except Exception as exception:
        raise exception
    return HttpResponse("This is message processing!")
